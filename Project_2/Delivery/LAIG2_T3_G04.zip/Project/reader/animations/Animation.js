/**
 * Animation
 * @constructor
 */
function Animation() {}
