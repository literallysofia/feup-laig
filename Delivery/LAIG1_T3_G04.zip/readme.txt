Turma 3
Grupo 4

(Grupo T3G04)

Estudantes:
Bárbara Sofia Lopez de Carvalho Ferreira da Silva ; up201505628
Julieta Pintado Jorge Frade ; up201506530
