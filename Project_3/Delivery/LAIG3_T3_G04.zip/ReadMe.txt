Turma: 3 (Quinta 8h30 RPR)
Grupo: 4

Estudantes:
Bárbara Sofia Lopez de Carvalho Ferreira da Silva - up201505628
Julieta Pintado Jorge Frade - up201506530